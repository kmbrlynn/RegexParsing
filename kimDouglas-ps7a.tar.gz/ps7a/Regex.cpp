// Copyright 2015 Kim Douglas
//
// This file is not technically needed for ps7a.
// It is included here for ps7b, which will involve more abstraction.
// The Makefile is set up accordingly.
